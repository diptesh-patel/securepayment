<?php
return [
    'status' => [
        'active' => 'active',
        'inactive' => 'inactive'
    ],
    'role' => [
        'admin' => '1',
        'merchant' => '2',
        'user' => '3'
    ],
    'mid_connector' => [
        
        'opayweb' => 'Opayweb',
        'payretailers'=>'Payretailers'
    ],
    'opayweb'=>[
        'testmode'=>'ON' // test mode ON or OFF
    ]
];
