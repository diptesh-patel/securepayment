<?php $__env->startSection('title', 'Merchants List'); ?>

<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/tables/datatable/responsive.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/tables/datatable/buttons.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/tables/datatable/rowGroup.bootstrap5.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/extensions/toastr.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('css/base/plugins/forms/form-validation.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/base/plugins/extensions/ext-component-toastr.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Basic table -->
<section id="admin_merchant">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <table class="datatables-basic table">
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th>id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Notify URL</th>
              <th>Role</th>
              <th>Action</th>
              <!-- <th>Action</th> -->
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </div>
  <!-- Modal to add new record -->
  
  
</section>
<!--/ Basic table -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
  
  <script src="<?php echo e(asset('vendors/js/tables/datatable/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/responsive.bootstrap5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.checkboxes.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.buttons.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/jszip.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/pdfmake.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/vfs_fonts.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/buttons.html5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/buttons.print.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/tables/datatable/dataTables.rowGroup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/pickers/flatpickr/flatpickr.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/forms/validation/jquery.validate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/js/extensions/toastr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
  
  <!-- <script src="<?php echo e(asset('js/scripts/tables/table-datatables-basic.js')); ?>"></script> -->
  <script>var merchantslistUrl = "<?php echo e(route('admin.getmerchantslist')); ?>";</script>
  <script src="<?php echo e(asset('js/scripts/tables/admin-merchant-datatables.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\secureEpayments\resources\views/admin/merchants/list.blade.php ENDPATH**/ ?>