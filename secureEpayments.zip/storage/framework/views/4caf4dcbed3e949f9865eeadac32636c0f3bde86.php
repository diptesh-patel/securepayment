<?php $__env->startSection('title', 'Merchants Settings'); ?>
<?php $__env->startSection('vendor-style'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/extensions/toastr.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  
  
  <link rel="stylesheet" href="<?php echo e(asset('css/base/plugins/extensions/ext-component-toastr.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Basic tabs start -->
<section id="settings_page">
   <div class="row match-height">
      <!-- Tabs with Icon starts -->
      <div class="col-xl-12 col-lg-12">
         <div class="card">
            <div class="card-header">
               <h4 class="card-title">Account Settings</h4>
            </div>
            <div class="card-body">
               <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="aboutIcon-tab" data-bs-toggle="tab" href="#aboutIcon" aria-controls="about" role="tab" aria-selected="false" ><i data-feather="user"></i> Account</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="profileIcon-tab" data-bs-toggle="tab" href="#profileIcon" aria-controls="profile" role="tab" aria-selected="false" ><i data-feather="lock"></i> security</a>
                  </li>
               </ul>
               <div class="tab-content">
                <?php echo $__env->make('merchant/settings/include/profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('merchant/settings/include/security', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
            </div>
         </div>
         <!-- recent device -->
         <?php echo $__env->make('merchant/settings/include/device', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
         <!-- / recent device -->
      </div>
      <!-- Tabs with Icon ends -->
      
   </div>
</section>
<!-- Basic Tabs end -->
  <?php echo $__env->make('merchant/settings/include/_modals/two-factor-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('vendors/js/extensions/toastr.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('js/scripts/components/settings.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/pages/modal-two-factor-auth.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\secureEpayments\resources\views/merchant/settings/index.blade.php ENDPATH**/ ?>