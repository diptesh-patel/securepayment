<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" href="<?php echo e(asset('vendors/css/vendors.min.css')); ?>" />

<?php echo $__env->yieldContent('vendor-style'); ?>
<!-- END: Vendor CSS-->

<!-- BEGIN: Theme CSS-->
<link rel="stylesheet" href="<?php echo e(asset('css/core.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/base/themes/dark-layout.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/base/themes/bordered-layout.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/base/themes/semi-dark-layout.css')); ?>" />


<!-- BEGIN: Page CSS-->
<link rel="stylesheet" href="<?php echo e(asset('css/base/core/menu/menu-types/vertical-menu.css')); ?>" />


<?php echo $__env->yieldContent('page-style'); ?>

<!-- laravel style -->
<link rel="stylesheet" href="<?php echo e(asset('css/overrides.css')); ?>" />

<!-- BEGIN: Custom CSS-->


  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
<?php /**PATH D:\wamp\www\secureEpayments\resources\views/panels/styles.blade.php ENDPATH**/ ?>