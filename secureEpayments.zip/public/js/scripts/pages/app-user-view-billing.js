$((function(){var t=$(".edit-address"),d=$(".address-title"),e=$(".address-subtitle");t.on("click",(function(){d.text("Edit Address"),e.text("Edit your current address")}))}));
