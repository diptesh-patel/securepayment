$((function(){"use strict";var r=$(".auth-forgot-password-form");r.length&&r.validate({rules:{"forgot-password-email":{required:!0,email:!0}}})}));
